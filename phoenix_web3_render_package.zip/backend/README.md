# Phoenix Web3 Backend
FastAPI AI backend.